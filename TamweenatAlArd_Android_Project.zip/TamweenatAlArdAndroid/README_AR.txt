مشروع مصمم إعلانات تموينات العرض - Android WebView

هذا مشروع Android يغلّف نسخة HTML التجريبية داخل تطبيق جوال.
يُبنى باستخدام Android Gradle Plugin 8.7.3 وGradle 8.9 وJava 17.

ملف HTML موجود في:
app/src/main/assets/index.html

لبناء APK على GitHub Actions، استخدم workflow المتوافق المرفق في رد ChatGPT.
